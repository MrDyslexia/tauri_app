"use client"

import { Card, CardHeader, CardBody, Button, Input } from "@heroui/react"
import { motion } from "framer-motion"

interface LoginViewProps {
  onLogin: () => void
}

export default function LoginView({ onLogin }: LoginViewProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="w-full glass-effect border-0 shadow-xl">
        <CardHeader className="text-center pb-4">
          <h1 className="text-xl font-light gradient-text">AI Assistant</h1>
        </CardHeader>
        <CardBody className="space-y-4">
          <div className="space-y-2">
            <div className="text-sm font-medium">Email</div>
            <Input className="h-9" id="email" type="email" />
          </div>
          <div className="space-y-2">
            <div className="text-sm font-medium">Password</div>
            <Input className="h-9" id="password" type="password" />
          </div>
          <Button
            className="w-full h-9 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
            onPress={onLogin}
          >
            Sign In
          </Button>
        </CardBody>
      </Card>
    </motion.div>
  )
}
