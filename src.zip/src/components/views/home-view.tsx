import { Card, CardHeader, CardBody, Button, Badge } from "@heroui/react"
import { Search, History } from "lucide-react"
import { motion } from "framer-motion"
import type { AssistantResponse } from "@/types/interfaces"

interface HomeViewProps {
  responses: AssistantResponse[]
  onNewSearch: () => void
  onSelectResponse: (response: AssistantResponse) => void
}

export default function HomeView({ responses, onNewSearch, onSelectResponse }: HomeViewProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="w-full bg-white/95 backdrop-blur-sm border-0 shadow-xl">
        <CardHeader className="pb-4">
          <h1 className="text-lg font-light">Recent Searches</h1>
        </CardHeader>
        <CardBody className="space-y-3">
          <div className="space-y-2">
            {responses.map((response, i) => (
              <motion.div
                key={i}
                className="flex items-center gap-2 p-2 rounded-lg hover:bg-gray-50 cursor-pointer hover-glow"
                role="button"
                tabIndex={0}
                onClick={() => onSelectResponse(response)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    onSelectResponse(response)
                  }
                }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <History className="h-4 w-4 text-gray-400" />
                <span className="text-sm text-gray-600 flex-1">{response.query}</span>
                <Badge className="text-xs" variant="flat">
                  {response.type}
                </Badge>
              </motion.div>
            ))}
          </div>
          <Button
            className="w-full h-9 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white mt-4"
            onPress={onNewSearch}
          >
            <Search className="h-4 w-4 mr-2" />
            New Search
          </Button>
        </CardBody>
      </Card>
    </motion.div>
  )
}
